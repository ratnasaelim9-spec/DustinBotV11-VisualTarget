# DustinBot V11.2 — Rune Classic Visual Target

This build uses Android Accessibility screenshot capture + ML Kit OCR.

Flow:
1. User enters a target monster name/ID.
2. Bot scans the game area for small colored candidate sprites.
3. It taps a candidate.
4. OCR checks the resulting target text against the requested monster.
5. When confirmed, it taps the confirmed target again.

Important: screen coordinates are not Game X/Y and the visual adapter does not invent a runtime Entity ID. Native Entity ID/Game X/Y still requires a Rune Classic-specific runtime structure or protocol source.
