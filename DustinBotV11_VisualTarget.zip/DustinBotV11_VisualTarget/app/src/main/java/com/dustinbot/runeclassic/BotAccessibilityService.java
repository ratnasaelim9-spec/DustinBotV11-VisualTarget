package com.dustinbot.runeclassic;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class BotAccessibilityService extends AccessibilityService {
    private static BotAccessibilityService instance;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final TextRecognizer ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private boolean running;
    private boolean busy;
    private String targetQuery="";
    private long lastTap;
    private long candidateIndex;
    private Candidate lastCandidate;
    private boolean targetConfirmed;
    private static final long SCAN_MS=650, VERIFY_MS=450, TAP_COOLDOWN=900;

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;}
    @Override public void onDestroy(){stopBot();ocr.close();instance=null;super.onDestroy();}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){stopBot();}
    public static BotAccessibilityService getInstance(){return instance;}
    public boolean isBotRunning(){return running;}
    public void setTarget(String q){targetQuery=q==null?"":q.trim();candidateIndex=0;targetConfirmed=false;}
    public void startBot(){if(running)return;running=true;targetConfirmed=false;scanSoon(0);}
    public void stopBot(){running=false;busy=false;handler.removeCallbacksAndMessages(null);}
    private void scanSoon(long ms){handler.postDelayed(()->{if(running)scan();},ms);}

    private void scan(){
        if(!running||busy)return;
        if(Build.VERSION.SDK_INT<30){scanSoon(SCAN_MS);return;}
        busy=true;
        takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult r){
                Bitmap hw=null,b=null; HardwareBuffer hb=null;
                try{
                    hb=r.getHardwareBuffer();
                    hw=Bitmap.wrapHardwareBuffer(hb,r.getColorSpace());
                    if(hw!=null)b=hw.copy(Bitmap.Config.ARGB_8888,false);
                    if(b!=null)processFrame(b);
                }catch(Exception ignored){}finally{
                    if(b!=null)b.recycle();
                    if(hw!=null&&hw!=b)try{hw.recycle();}catch(Exception ignored){}
                    if(hb!=null)try{hb.close();}catch(Exception ignored){}
                    busy=false;if(running)scanSoon(SCAN_MS);
                }
            }
            @Override public void onFailure(int code){busy=false;if(running)scanSoon(SCAN_MS);}
        });
    }

    private void processFrame(Bitmap b){
        if(lastCandidate!=null && !targetConfirmed){
            verifyTarget(b,lastCandidate);
            return;
        }
        List<Candidate> cs=findCandidates(b);
        if(cs.isEmpty())return;
        // Cycle candidates instead of repeatedly tapping the same object.
        int idx=(int)(candidateIndex%cs.size());
        lastCandidate=cs.get(idx);candidateIndex++;
        long now=System.currentTimeMillis();
        if(now-lastTap<TAP_COOLDOWN)return;
        lastTap=now;
        tap(lastCandidate.x,lastCandidate.y);
        handler.postDelayed(()->verifyByNewScreenshot(lastCandidate),VERIFY_MS);
    }

    private void verifyByNewScreenshot(Candidate c){
        if(!running)return;
        // Keep the candidate and let the next normal screenshot run OCR.
    }

    private void verifyTarget(Bitmap b,Candidate c){
        final String wanted=MonsterDatabase.norm(targetQuery);
        if(wanted.isEmpty()){lastCandidate=null;return;}
        InputImage input=InputImage.fromBitmap(b,0);
        ocr.process(input).addOnSuccessListener(result->{
            boolean hit=false;
            outer: for(Text.TextBlock block:result.getTextBlocks()) for(Text.Line line:block.getLines()){
                String raw=line.getText();String n=MonsterDatabase.norm(raw);
                if(n.length()<3)continue;
                if(n.equals(wanted)||n.contains(wanted)||wanted.contains(n)){hit=true;break outer;}
            }
            if(hit){
                targetConfirmed=true;
                // A second tap on the confirmed target is the only game-side action
                // we can safely infer from the reference video; attack/skill coordinates
                // remain configurable rather than guessed.
                long now=System.currentTimeMillis();
                if(now-lastTap>=TAP_COOLDOWN){lastTap=now;tap(c.x,c.y);}
            }else{
                targetConfirmed=false;
                lastCandidate=null;
            }
        }).addOnFailureListener(e->{lastCandidate=null;targetConfirmed=false;});
    }

    private List<Candidate> findCandidates(Bitmap b){
        int w=b.getWidth(),h=b.getHeight(),step=3;
        int gw=Math.max(1,w/step),gh=Math.max(1,h/step);
        boolean[][] seen=new boolean[gh][gw];List<Candidate> out=new ArrayList<>();
        for(int gy=0;gy<gh;gy++)for(int gx=0;gx<gw;gx++){
            if(seen[gy][gx])continue;
            int x=gx*step,y=gy*step;
            if(!inGameArea(x,y,w,h)){seen[gy][gx]=true;continue;}
            if(!isCandidatePixel(b.getPixel(x,y))){seen[gy][gx]=true;continue;}
            Candidate c=flood(b,gx,gy,step,seen);
            if(c==null)continue;
            // Mob-sized colored blobs; reject huge UI/player-like regions.
            if(c.count>=5&&c.count<=450&&c.width>=5&&c.height>=5&&c.width<=100&&c.height<=100)out.add(c);
        }
        out.sort(Comparator.comparingDouble(c->score(c,w,h)));
        Collections.reverse(out);
        return out;
    }

    private boolean inGameArea(int x,int y,int w,int h){
        // Ignore top status/UI, bottom hotbar and right-side controls/minimap.
        if(y<70||y>h-115)return false;
        if(x<35||x>w-90)return false;
        return true;
    }
    private double score(Candidate c,int w,int h){
        double dx=c.x-w/2.0,dy=c.y-h/2.0;
        double center=1200.0/(1.0+Math.hypot(dx,dy));
        double size=Math.min(c.count,160);
        return center+size;
    }
    private boolean isCandidatePixel(int color){
        float[] hsv=new float[3];Color.RGBToHSV(Color.red(color),Color.green(color),Color.blue(color),hsv);
        return hsv[1]>=0.30f&&hsv[2]>=0.28f;
    }
    private Candidate flood(Bitmap b,int sx,int sy,int step,boolean[][] seen){
        int gw=seen[0].length,gh=seen.length;ArrayDeque<int[]> q=new ArrayDeque<>();q.add(new int[]{sx,sy});seen[sy][sx]=true;
        int count=0,minx=sx,maxx=sx,miny=sy,maxy=sy;long sumx=0,sumy=0;
        while(!q.isEmpty()){
            int[] p=q.removeFirst();int gx=p[0],gy=p[1],px=gx*step,py=gy*step;
            if(px>=b.getWidth()||py>=b.getHeight()||!isCandidatePixel(b.getPixel(px,py)))continue;
            count++;sumx+=px;sumy+=py;minx=Math.min(minx,gx);maxx=Math.max(maxx,gx);miny=Math.min(miny,gy);maxy=Math.max(maxy,gy);
            add(q,gx+1,gy,gw,gh,seen);add(q,gx-1,gy,gw,gh,seen);add(q,gx,gy+1,gw,gh,seen);add(q,gx,gy-1,gw,gh,seen);
        }
        if(count==0)return null;Candidate c=new Candidate();c.count=count;c.x=(int)(sumx/count);c.y=(int)(sumy/count);c.width=(maxx-minx+1)*step;c.height=(maxy-miny+1)*step;return c;
    }
    private void add(ArrayDeque<int[]>q,int x,int y,int gw,int gh,boolean[][]seen){if(x<0||y<0||x>=gw||y>=gh||seen[y][x])return;seen[y][x]=true;q.add(new int[]{x,y});}
    private void tap(float x,float y){
        if(Build.VERSION.SDK_INT<24)return;Path p=new Path();p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();
        dispatchGesture(g,null,null);
    }
    private static final class Candidate{int x,y,width,height,count;}
}
