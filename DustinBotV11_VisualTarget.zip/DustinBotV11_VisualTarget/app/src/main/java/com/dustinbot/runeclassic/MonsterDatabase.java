package com.dustinbot.runeclassic;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MonsterDatabase {
    public static final class Monster {
        public final int id; public final String code; public final String name;
        Monster(int id,String code,String name){this.id=id;this.code=code;this.name=name;}
    }
    private final List<Monster> all=new ArrayList<>();
    public MonsterDatabase(Context c){
        try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getAssets().open("monster_database.json")))){
            StringBuilder s=new StringBuilder(); String line; while((line=r.readLine())!=null)s.append(line);
            JSONArray a=new JSONObject(s.toString()).getJSONArray("monsters");
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);all.add(new Monster(o.getInt("id"),o.getString("code"),o.getString("name")));}
        }catch(Exception ignored){}
    }
    public List<Monster> all(){return new ArrayList<>(all);}
    public Monster find(String q){
        if(q==null)return null; String x=norm(q); if(x.isEmpty())return null;
        for(Monster m:all) if(norm(m.name).equals(x)||norm(m.code).equals(x)||String.valueOf(m.id).equals(x)) return m;
        for(Monster m:all) if(norm(m.name).contains(x)||norm(m.code).contains(x)) return m;
        return null;
    }
    public static String norm(String s){return s==null?"":s.toLowerCase(Locale.US).replaceAll("[^a-z0-9]","");}
}
