package com.dustinbot.runeclassic;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView status; private EditText target;
    @Override protected void onCreate(Bundle b){super.onCreate(b); build();}
    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,40,32,32); root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title=new TextView(this); title.setText("DustinBot V11\nRune Classic"); title.setTextSize(26); title.setGravity(Gravity.CENTER); root.addView(title);
        status=new TextView(this); status.setText("สถานะ: พร้อม"); status.setTextSize(17); status.setPadding(0,25,0,20); root.addView(status);
        target=new EditText(this); target.setHint("Monster เช่น Poring หรือ 1002"); root.addView(target,new LinearLayout.LayoutParams(-1,-2));
        Button access=new Button(this); access.setText("1. เปิด Accessibility"); root.addView(access);
        Button start=new Button(this); start.setText("2. เริ่มบอท"); root.addView(start);
        Button stop=new Button(this); stop.setText("หยุดบอท"); root.addView(stop);
        TextView info=new TextView(this); info.setText("โหมด V11.2: Screen Scanner → เลือกเป้าหมาย → ตรวจชื่อด้วย OCR → แตะเป้าหมาย\nพิกัดที่ใช้ในขั้นนี้เป็นพิกัดหน้าจอ ยังไม่อ้างว่าเป็น Game X/Y หรือ Entity ID"); info.setPadding(0,25,0,0); root.addView(info);
        setContentView(root);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        start.setOnClickListener(v->{BotAccessibilityService s=BotAccessibilityService.getInstance(); if(s==null){status.setText("สถานะ: เปิด Accessibility ก่อน");return;} String q=target.getText().toString().trim(); if(q.isEmpty()){status.setText("กรุณาระบุ Monster");return;} s.setTarget(q); s.startBot(); status.setText("สถานะ: กำลังหา "+q);});
        stop.setOnClickListener(v->{BotAccessibilityService s=BotAccessibilityService.getInstance(); if(s!=null)s.stopBot(); status.setText("สถานะ: หยุดแล้ว");});
    }
    public static void postStatus(String x){ }
}
